class SnakeGame {
    constructor() {
        this.canvas = document.getElementById('gameCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.gridSize = 20;
        this.tileCount = this.canvas.width / this.gridSize;
        
        this.reset();
        this.setupEventListeners();
        this.setupUI();
    }

    reset() {
        this.snake = [
            {x: 10, y: 10}
        ];
        this.food = this.generateFood();
        this.direction = {x: 0, y: 0};
        this.nextDirection = {x: 0, y: 0};
        this.score = 0;
        this.gameSpeed = 10;
        this.level = 1;
        this.gameOver = false;
        this.paused = true;
        this.growPending = 0;
        
        // Начальная длина змейки
        for (let i = 0; i < 2; i++) {
            this.snake.push({...this.snake[0]});
        }
        
        this.updateUI();
    }

    generateFood() {
        let newFood;
        let onSnake;
        
        do {
            newFood = {
                x: Math.floor(Math.random() * this.tileCount),
                y: Math.floor(Math.random() * this.tileCount)
            };
            onSnake = this.snake.some(segment => 
                segment.x === newFood.x && segment.y === newFood.y
            );
        } while (onSnake);
        
        return newFood;
    }

    draw() {
        // Очистка canvas
        this.ctx.fillStyle = '#0a0a1a';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // Рисуем сетку
        this.drawGrid();

        // Рисуем еду
        this.drawFood();

        // Рисуем змейку
        this.drawSnake();
    }

    drawGrid() {
        this.ctx.strokeStyle = 'rgba(0, 255, 136, 0.1)';
        this.ctx.lineWidth = 1;
        
        for (let x = 0; x < this.tileCount; x++) {
            for (let y = 0; y < this.tileCount; y++) {
                this.ctx.strokeRect(
                    x * this.gridSize, 
                    y * this.gridSize, 
                    this.gridSize, 
                    this.gridSize
                );
            }
        }
    }

    drawSnake() {
        this.snake.forEach((segment, index) => {
            const isHead = index === 0;
            
            if (isHead) {
                this.ctx.fillStyle = '#00ff88';
                this.ctx.shadowColor = '#00ff88';
                this.ctx.shadowBlur = 15;
            } else {
                const colorValue = 200 - (index * 5);
                this.ctx.fillStyle = `rgb(0, ${colorValue}, 100)`;
                this.ctx.shadowBlur = 5;
            }
            
            this.ctx.fillRect(
                segment.x * this.gridSize,
                segment.y * this.gridSize,
                this.gridSize - 1,
                this.gridSize - 1
            );
            
            // Глаза у головы
            if (isHead) {
                this.ctx.fillStyle = '#000';
                const eyeSize = this.gridSize / 5;
                
                let leftEye = {x: 0, y: 0};
                let rightEye = {x: 0, y: 0};
                
                if (this.direction.x === 1) {
                    leftEye = {x: this.gridSize - eyeSize, y: eyeSize * 2};
                    rightEye = {x: this.gridSize - eyeSize, y: this.gridSize - eyeSize * 2};
                } else if (this.direction.x === -1) {
                    leftEye = {x: eyeSize, y: eyeSize * 2};
                    rightEye = {x: eyeSize, y: this.gridSize - eyeSize * 2};
                } else if (this.direction.y === 1) {
                    leftEye = {x: eyeSize * 2, y: this.gridSize - eyeSize};
                    rightEye = {x: this.gridSize - eyeSize * 2, y: this.gridSize - eyeSize};
                } else {
                    leftEye = {x: eyeSize * 2, y: eyeSize};
                    rightEye = {x: this.gridSize - eyeSize * 2, y: eyeSize};
                }
                
                this.ctx.fillRect(
                    segment.x * this.gridSize + leftEye.x,
                    segment.y * this.gridSize + leftEye.y,
                    eyeSize, eyeSize
                );
                this.ctx.fillRect(
                    segment.x * this.gridSize + rightEye.x,
                    segment.y * this.gridSize + rightEye.y,
                    eyeSize, eyeSize
                );
            }
        });
        this.ctx.shadowBlur = 0;
    }

    drawFood() {
        const pulse = Math.sin(Date.now() * 0.01) * 0.3 + 0.7;
        
        this.ctx.fillStyle = `rgba(255, 50, 50, ${pulse})`;
        this.ctx.shadowColor = '#ff0000';
        this.ctx.shadowBlur = 20;
        
        this.ctx.beginPath();
        this.ctx.arc(
            this.food.x * this.gridSize + this.gridSize / 2,
            this.food.y * this.gridSize + this.gridSize / 2,
            this.gridSize / 2 - 2, 0, Math.PI * 2
        );
        this.ctx.fill();
        
        this.ctx.shadowBlur = 0;
    }

    update() {
        if (this.paused || this.gameOver) return;

        this.direction = {...this.nextDirection};

        const head = {...this.snake[0]};
        head.x += this.direction.x;
        head.y += this.direction.y;

        // Телепортация через стены
        if (head.x < 0) head.x = this.tileCount - 1;
        if (head.x >= this.tileCount) head.x = 0;
        if (head.y < 0) head.y = this.tileCount - 1;
        if (head.y >= this.tileCount) head.y = 0;

        // Проверка столкновения с собой
        if (this.snake.some(segment => segment.x === head.x && segment.y === head.y)) {
            this.gameOver = true;
            this.showGameOver();
            return;
        }

        this.snake.unshift(head);

        if (head.x === this.food.x && head.y === this.food.y) {
            this.score += 10;
            this.food = this.generateFood();
            this.growPending = 5;
            
            // Увеличиваем скорость
            if (this.score % 50 === 0) {
                this.gameSpeed = Math.min(this.gameSpeed + 1, 20);
                this.level++;
            }
            
            this.playSound('eatSound');
        } else {
            this.snake.pop();
        }

        this.updateUI();
    }

    updateUI() {
        document.getElementById('score').textContent = this.score;
        document.getElementById('length').textContent = this.snake.length;
        document.getElementById('level').textContent = this.level;
    }

    setupEventListeners() {
        document.addEventListener('keydown', (e) => {
            switch(e.key) {
                case 'ArrowUp':
                case 'w':
                case 'W':
                    if (this.direction.y === 0) this.nextDirection = {x: 0, y: -1};
                    break;
                case 'ArrowDown':
                case 's':
                case 'S':
                    if (this.direction.y === 0) this.nextDirection = {x: 0, y: 1};
                    break;
                case 'ArrowLeft':
                case 'a':
                case 'A':
                    if (this.direction.x === 0) this.nextDirection = {x: -1, y: 0};
                    break;
                case 'ArrowRight':
                case 'd':
                case 'D':
                    if (this.direction.x === 0) this.nextDirection = {x: 1, y: 0};
                    break;
                case ' ':
                    e.preventDefault();
                    this.togglePause();
                    break;
                case 'r':
                case 'R':
                    this.resetGame();
                    break;
            }
        });

        // Мобильное управление
        document.querySelectorAll('.mobile-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const direction = btn.getAttribute('data-direction');
                this.changeDirection(direction);
            });
        });
    }

    setupUI() {
        document.getElementById('startBtn').addEventListener('click', () => {
            this.startGame();
        });

        document.getElementById('pauseBtn').addEventListener('click', () => {
            this.togglePause();
        });

        document.getElementById('resetBtn').addEventListener('click', () => {
            this.resetGame();
        });

        document.getElementById('restartBtn').addEventListener('click', () => {
            this.resetGame();
        });
    }

    changeDirection(direction) {
        if (this.paused || this.gameOver) return;
        
        switch(direction) {
            case 'up':
                if (this.direction.y === 0) this.nextDirection = {x: 0, y: -1};
                break;
            case 'down':
                if (this.direction.y === 0) this.nextDirection = {x: 0, y: 1};
                break;
            case 'left':
                if (this.direction.x === 0) this.nextDirection = {x: -1, y: 0};
                break;
            case 'right':
                if (this.direction.x === 0) this.nextDirection = {x: 1, y: 0};
                break;
        }
    }

    startGame() {
        this.paused = false;
        this.gameOver = false;
        document.getElementById('startBtn').disabled = true;
        document.getElementById('pauseBtn').disabled = false;
        this.hideGameOver();
        
        // Начальное направление
        if (this.direction.x === 0 && this.direction.y === 0) {
            this.nextDirection = {x: 1, y: 0};
        }
    }

    togglePause() {
        this.paused = !this.paused;
        document.getElementById('pauseBtn').textContent = this.paused ? 'Продолжить' : 'Пауза';
    }

    resetGame() {
        this.reset();
        this.hideGameOver();
        document.getElementById('startBtn').disabled = false;
        document.getElementById('pauseBtn').disabled = true;
        document.getElementById('pauseBtn').textContent = 'Пауза';
    }

    showGameOver() {
        document.getElementById('finalScore').textContent = this.score;
        document.getElementById('gameOver').classList.remove('hidden');
        this.playSound('gameOverSound');
    }

    hideGameOver() {
        document.getElementById('gameOver').classList.add('hidden');
    }

    playSound(soundId) {
        const sound = document.getElementById(soundId);
        if (sound) {
            sound.currentTime = 0;
            sound.play().catch(e => console.log('Audio play failed:', e));
        }
    }

    gameLoop() {
        this.update();
        this.draw();
    }

    start() {
        this.interval = setInterval(() => this.gameLoop(), 1000 / this.gameSpeed);
    }

    stop() {
        if (this.interval) {
            clearInterval(this.interval);
        }
    }
}

// Запуск игры
const game = new SnakeGame();
game.start();